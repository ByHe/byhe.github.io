package se.egy.examples.tilemap;
import se.egy.graphics.*;

public class TestMap_1a {
	public static void main(String[] args) { 
		// 25x32 = 800  18x32 = 576
		GameScreen gs = new GameScreen("TileMap 1", 800, 576, false);
		
		TileMap map = new TileMap("map-colors.txt", 32);
		
		gs.setBackground(map);
		gs.beginRender();
		gs.show();
	}
}
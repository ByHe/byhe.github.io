package se.egy.examples.tilemap;
import java.awt.Image;
import javax.swing.ImageIcon;
import se.egy.graphics.*;

public class TestMap_2 {

	public TestMap_2() {
		// 25x32 = 800  18x32 = 576
		GameScreen gs = new GameScreen("TileMap 2", 800, 576, false);

		// Läser in bilder
		Image[] imgArray = new Image[5];

		for(int i = 0; i < 5; i++) {
			imgArray[i] = new ImageIcon(getClass().getResource("/tile-" + i + ".png")).getImage();
		}

		TileMap map = new TileMap("map-images.txt", 32, imgArray);
		gs.setBackground(map);

		gs.beginRender();
		gs.show();
	}

	public static void main(String[] args) { 
		new TestMap_2();
	}
}
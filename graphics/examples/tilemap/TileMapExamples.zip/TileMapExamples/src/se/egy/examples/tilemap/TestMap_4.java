package se.egy.examples.tilemap;

import java.awt.Image;
import javax.swing.ImageIcon;
import se.egy.graphics.*;

public class TestMap_4 {

	public TestMap_4() {
		// 25x32 = 800  18x32 = 576
		GameScreen gs = new GameScreen("TileMap 4", 800, 576, false);

		Image tileSet = new ImageIcon(getClass().getResource("/tileset-mario.png")).getImage();
		Image[] imgArray = ImageTools.slice(tileSet, 16, 16, 0);

		TileMap map = new TileMap("mapLarge-mario.txt", 32, imgArray);
		gs.setBackground(map);

		gs.beginRender();
		gs.show();
	}

	public static void main(String[] args) { 
		new TestMap_4();
	}
}

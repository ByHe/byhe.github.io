package se.egy.examples.tilemap;
import java.awt.Color;

import se.egy.graphics.*;

public class TestMap_1b {
	public static void main(String[] args) { 
		// 25x32 = 800  18x32 = 576
		GameScreen gs = new GameScreen("TileMap 1", 800, 576, false);

		Color[] colorArray = {	
				Color.BLACK, Color.WHITE,new Color(100,10,55),Color.GRAY,Color.RED,
				Color.YELLOW,Color.BLUE,Color.GREEN,Color.ORANGE,Color.WHITE,Color.PINK,Color.CYAN,
				Color.MAGENTA,new Color(0,0,0,0)};

		TileMap map = new TileMap("map-colors.txt", 32, colorArray);

		gs.setBackground(map);
		gs.beginRender();
		gs.show();
	}
}
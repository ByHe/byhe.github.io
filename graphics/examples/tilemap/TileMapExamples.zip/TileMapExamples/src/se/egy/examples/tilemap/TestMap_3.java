package se.egy.examples.tilemap;

import java.awt.Image;
import javax.swing.ImageIcon;
import se.egy.graphics.*;

public class TestMap_3 {

	public TestMap_3() {
		// 25x32 = 800  18x32 = 576
		GameScreen gs = new GameScreen("TileMap 3", 800, 576, false);

		Image tileSet = new ImageIcon(getClass().getResource("/tileset.png")).getImage();
		Image[] imgArray = ImageTools.slice(tileSet, 5, 1, 1);

		TileMap map = new TileMap("map-images.txt", 32, imgArray);
		gs.setBackground(map);

		gs.beginRender();
		gs.show();
	}

	public static void main(String[] args) { 
		new TestMap_3();
	}
}

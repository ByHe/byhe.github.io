
// Laddar in bilder till spelet
let birdImg = new Image();
birdImg.src = "img/bird.png";

let birdSprite;

// Position
let xPos = 260, yPos = 220;

/** Körs då sidan är laddad */
function init(){
	document.addEventListener("keydown", keyDown);

	gameLoop();
}

/** Sparar undan en tangentryckning för bearbetning  */
function keyDown(e){
	if ( e.keyCode == 37) { // Vänster
		xPos -= 5;
	}if (e.keyCode == 39) { // Höger
		xPos += 5;
	}
	if (e.keyCode == 38) { // Upp
		yPos -= 5;
	}
	if (e.keyCode == 40) { // Ner
		yPos += 5;
	}
}

/** Spellopen */
function gameLoop() {
	render();

	// Bytt till requestAnimFrame istället för setInterval
	requestAnimationFrame(function() {
        gameLoop();
      });
}

/** Renderar canvasen */
function render(){
	let canvas = document.getElementById('gameCanvas');
	let ctx = canvas.getContext( '2d' );
	
	// Ser till att radera med vit bakgrund som det sedan skall ritas på
	ctx.save();
	ctx.fillStyle = "white";
	ctx.fillRect(0,0,canvas.width, canvas.height);

	ctx.drawImage(birdImg, xPos, yPos);
	
	ctx.restore();
}


window.addEventListener("load",init);

